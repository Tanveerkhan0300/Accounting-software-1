ALTER TABLE public.cash_book_entries ADD COLUMN IF NOT EXISTS period text NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS cash_book_entries_period_idx ON public.cash_book_entries (period);