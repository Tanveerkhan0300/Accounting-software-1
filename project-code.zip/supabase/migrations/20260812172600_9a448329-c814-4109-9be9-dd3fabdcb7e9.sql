
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.app_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings_all" ON public.app_settings FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER app_settings_updated BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.cash_book_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date DATE,
  description TEXT NOT NULL DEFAULT '',
  receipts NUMERIC NOT NULL DEFAULT 0,
  payments NUMERIC NOT NULL DEFAULT 0,
  remarks TEXT NOT NULL DEFAULT '',
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cash_book_entries TO authenticated;
GRANT ALL ON public.cash_book_entries TO service_role;
ALTER TABLE public.cash_book_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cash_all" ON public.cash_book_entries FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER cash_updated BEFORE UPDATE ON public.cash_book_entries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_name TEXT NOT NULL DEFAULT '',
  father_name TEXT NOT NULL DEFAULT '',
  designation TEXT NOT NULL DEFAULT '',
  qualification TEXT NOT NULL DEFAULT '',
  experience TEXT NOT NULL DEFAULT '',
  cnic_no TEXT NOT NULL DEFAULT '',
  mobile_no TEXT NOT NULL DEFAULT '',
  kin_contact_no TEXT NOT NULL DEFAULT '',
  relation TEXT NOT NULL DEFAULT '',
  village TEXT NOT NULL DEFAULT '',
  tehsil TEXT NOT NULL DEFAULT '',
  district TEXT NOT NULL DEFAULT '',
  reference_by TEXT NOT NULL DEFAULT '',
  job_description TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  camp_site TEXT NOT NULL DEFAULT '',
  joining_date DATE,
  current_salary NUMERIC NOT NULL DEFAULT 0,
  revised_salary NUMERIC,
  revised_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employees TO authenticated;
GRANT ALL ON public.employees TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "emp_all" ON public.employees FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER emp_updated BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.salary_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  period TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  employee_name TEXT NOT NULL DEFAULT '',
  designation TEXT NOT NULL DEFAULT '',
  joining_date DATE,
  gross_salary NUMERIC NOT NULL DEFAULT 0,
  days NUMERIC NOT NULL DEFAULT 30,
  advance NUMERIC NOT NULL DEFAULT 0,
  employee_id UUID REFERENCES public.employees(id) ON DELETE SET NULL,
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.salary_entries TO authenticated;
GRANT ALL ON public.salary_entries TO service_role;
ALTER TABLE public.salary_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sal_all" ON public.salary_entries FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER sal_updated BEFORE UPDATE ON public.salary_entries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.demands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_no TEXT NOT NULL DEFAULT '',
  demand_date DATE,
  project TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.demands TO authenticated;
GRANT ALL ON public.demands TO service_role;
ALTER TABLE public.demands ENABLE ROW LEVEL SECURITY;
CREATE POLICY "dem_all" ON public.demands FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER dem_updated BEFORE UPDATE ON public.demands FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.demand_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_id UUID NOT NULL REFERENCES public.demands(id) ON DELETE CASCADE,
  description TEXT NOT NULL DEFAULT '',
  ref TEXT NOT NULL DEFAULT '',
  qty NUMERIC NOT NULL DEFAULT 0,
  rate NUMERIC NOT NULL DEFAULT 0,
  remarks TEXT NOT NULL DEFAULT '',
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.demand_items TO authenticated;
GRANT ALL ON public.demand_items TO service_role;
ALTER TABLE public.demand_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "demitem_all" ON public.demand_items FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER demitem_updated BEFORE UPDATE ON public.demand_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.advance_rows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL DEFAULT '',
  camp_site TEXT NOT NULL DEFAULT '',
  opening NUMERIC NOT NULL DEFAULT 0,
  values JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.advance_rows TO authenticated;
GRANT ALL ON public.advance_rows TO service_role;
ALTER TABLE public.advance_rows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "adv_all" ON public.advance_rows FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER adv_updated BEFORE UPDATE ON public.advance_rows FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
