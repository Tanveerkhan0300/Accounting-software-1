import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpenCheck, FileSpreadsheet, Printer, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ALM Accounts — Al Mehreen Enterprises Software" },
      {
        name: "description",
        content:
          "Cash book, staff salary sheets, payslips, employee profiles, demand sheets and advance salary registers for Al Mehreen Enterprises (ALM) Chitral Roads project.",
      },
      { property: "og:title", content: "ALM Accounts — Al Mehreen Enterprises Software" },
      {
        property: "og:description",
        content:
          "Excel-style, fully editable accounts software with Excel export, printing and permanent cloud storage.",
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  {
    icon: BookOpenCheck,
    title: "Cash Book & Expense Detail",
    text: "Opening balance, receipts, payments and a running balance calculated automatically.",
  },
  {
    icon: FileSpreadsheet,
    title: "Salary, Demand & Advances",
    text: "Department summary, team sheets, payslips, employee profiles and advance salary register.",
  },
  {
    icon: Printer,
    title: "Separate Export & Print",
    text: "Every sheet has its own Excel export, CSV download and print — exactly like your proformas.",
  },
  {
    icon: ShieldCheck,
    title: "Permanent Cloud Storage",
    text: "Every entry is saved in a secure database, so nothing is lost when you close the browser.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-sidebar px-6 py-4 text-sidebar-foreground">
        <div className="mx-auto flex max-w-5xl items-center justify-between">
          <div>
            <div className="font-display text-lg font-extrabold text-sidebar-primary">ALM</div>
            <div className="text-xs text-sidebar-foreground/75">Al Mehreen Enterprises (ALM)</div>
          </div>
          <Button asChild size="sm" variant="secondary">
            <Link to="/auth">Sign in</Link>
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-14">
        <h1 className="font-display text-4xl font-extrabold tracking-tight text-foreground md:text-5xl">
          ALM Accounts Software
        </h1>
        <p className="mt-3 max-w-2xl text-base text-muted-foreground">
          Chitral Project (ALM) Birmough to Istor — an empty, fully editable Excel-style system for
          cash book, staff salary sheets, payslips, employee profiles, demand sheets and advance
          salaries. Enter your own data; formulas and totals update themselves.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild>
            <Link to="/auth">Open the software</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/dashboard">Go to dashboard</Link>
          </Button>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-lg border border-border bg-card p-5 shadow-sm">
              <Icon className="size-5 text-primary" />
              <h2 className="mt-3 font-display text-base font-bold">{title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
