import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowUpRight,
  BookOpenCheck,
  ClipboardList,
  Coins,
  ReceiptText,
  TrendingDown,
  TrendingUp,
  Users,
  Wallet,
} from "lucide-react";

import { useRows } from "@/lib/db";
import { useCompany } from "@/lib/company";
import { fmt, num, periodLabel } from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Overview of cash balance, staff strength, salaries and advances for the ALM Chitral Roads project.",
      },
      { property: "og:title", content: "Dashboard — ALM Accounts Software" },
      { property: "og:description", content: "Live totals across every ALM accounts register." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

const MODULES = [
  { to: "/cash-book", label: "Cash Book", icon: BookOpenCheck, text: "Receipts, payments, balance" },
  { to: "/salary", label: "Staff Salary Sheet", icon: Wallet, text: "Summary + team sheets" },
  { to: "/payslip", label: "Salary Payslip", icon: ReceiptText, text: "Print employee payslips" },
  { to: "/employees", label: "Employee Profiles", icon: Users, text: "Full profile records" },
  { to: "/demand", label: "Demand Sheet", icon: ClipboardList, text: "Site material demands" },
  { to: "/advance", label: "Advance Salaries", icon: Coins, text: "Month-wise advance register" },
] as const;

function Kpi({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone: "primary" | "positive" | "negative" | "accent" | "muted";
}) {
  const tones: Record<string, string> = {
    primary: "from-primary/15 to-primary/5 text-primary border-primary/25",
    positive: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 border-emerald-500/25",
    negative: "from-destructive/15 to-destructive/5 text-destructive border-destructive/25",
    accent: "from-accent/40 to-accent/10 text-accent-foreground border-accent/50",
    muted: "from-muted to-card text-muted-foreground border-border",
  };
  return (
    <div
      className={`rounded-xl border bg-gradient-to-br p-4 shadow-sm ${tones[tone]}`}
    >
      <div className="text-[11px] font-semibold uppercase tracking-wider opacity-80">{label}</div>
      <div className="mt-1 font-display text-2xl font-bold tabular-nums text-foreground">{value}</div>
      {hint ? <div className="mt-0.5 text-[11px] opacity-80">{hint}</div> : null}
    </div>
  );
}

function Dashboard() {
  const { company } = useCompany();
  const cash = useRows("cash_book_entries", { orderBy: "sort_index" });
  const salary = useRows("salary_entries");
  const employees = useRows("employees", { orderBy: "created_at" });
  const advances = useRows("advance_rows");

  const cashRows = cash.data ?? [];
  const receipts = cashRows.reduce((s, r) => s + num(r["receipts"]), 0);
  const payments = cashRows.reduce((s, r) => s + num(r["payments"]), 0);

  const salaryRows = salary.data ?? [];
  const due = salaryRows.reduce((s, r) => s + (num(r["gross_salary"]) * num(r["days"])) / 30, 0);
  const salaryAdvance = salaryRows.reduce((s, r) => s + num(r["advance"]), 0);
  const payable = due - salaryAdvance;

  const advanceTotal = (advances.data ?? []).reduce((s, r) => {
    const vals = (r["values"] ?? {}) as Record<string, { amt?: number; adj?: number }>;
    return (
      s + num(r["opening"]) + Object.values(vals).reduce((a, v) => a + num(v.amt) - num(v.adj), 0)
    );
  }, 0);

  // Month-wise cash book
  const months = (() => {
    const map = new Map<string, { r: number; p: number; n: number }>();
    cashRows.forEach((row) => {
      const p = String(row["period"] ?? "");
      if (!p) return;
      const cur = map.get(p) ?? { r: 0, p: 0, n: 0 };
      cur.r += num(row["receipts"]);
      cur.p += num(row["payments"]);
      cur.n += 1;
      map.set(p, cur);
    });
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  })();

  // Department-wise staff strength from salary entries (latest data per department)
  const departments = (() => {
    const map = new Map<string, { count: number; due: number; advance: number }>();
    salaryRows.forEach((r) => {
      const d = String(r["department"] ?? "").trim() || "Unassigned";
      const cur = map.get(d) ?? { count: 0, due: 0, advance: 0 };
      cur.count += 1;
      cur.due += (num(r["gross_salary"]) * num(r["days"])) / 30;
      cur.advance += num(r["advance"]);
      map.set(d, cur);
    });
    return [...map.entries()].sort((a, b) => b[1].count - a[1].count);
  })();

  const empList = employees.data ?? [];

  return (
    <div>
      <div className="no-print mb-5 overflow-hidden rounded-xl border border-border bg-card shadow-sm">
        <div className="h-1.5 w-full bg-gradient-to-r from-primary via-ring to-accent" />
        <div className="bg-gradient-to-br from-primary/10 via-card to-accent/10 px-5 py-4">
          <h1 className="font-display text-2xl font-bold tracking-tight">Accounts Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            {company.name} — {company.project}
          </p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Kpi
          label="Cash Balance"
          value={fmt(receipts - payments)}
          hint={`${months.length} month(s) recorded`}
          tone="primary"
        />
        <Kpi label="Total Receipts" value={fmt(receipts)} hint="All cash books" tone="positive" />
        <Kpi label="Total Payments" value={fmt(payments)} hint="All cash books" tone="negative" />
        <Kpi label="Due Salary" value={fmt(due)} hint="All salary sheets" tone="accent" />
        <Kpi label="Payable Salary" value={fmt(payable)} hint={`Advance ${fmt(salaryAdvance)}`} tone="primary" />
        <Kpi
          label="Closing Advances"
          value={fmt(advanceTotal)}
          hint={`${(advances.data ?? []).length} advance rows`}
          tone="muted"
        />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-base font-bold">Cash Book — month wise</h2>
            <Link to="/cash-book" className="text-xs font-semibold text-primary hover:underline">
              Open <ArrowUpRight className="inline size-3" />
            </Link>
          </div>
          {months.length === 0 ? (
            <p className="text-sm text-muted-foreground">Abhi koi cash book entry nahi hai.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-2">Month</th>
                    <th className="py-2 text-right">Receipts</th>
                    <th className="py-2 text-right">Payments</th>
                    <th className="py-2 text-right">Balance</th>
                    <th className="py-2 text-right">Entries</th>
                  </tr>
                </thead>
                <tbody>
                  {months.map(([p, t]) => (
                    <tr key={p} className="border-b border-border/60 last:border-0">
                      <td className="py-2 font-medium">{periodLabel(p)}</td>
                      <td className="py-2 text-right tabular-nums text-emerald-600">{fmt(t.r)}</td>
                      <td className="py-2 text-right tabular-nums text-destructive">{fmt(t.p)}</td>
                      <td className="py-2 text-right font-semibold tabular-nums">{fmt(t.r - t.p)}</td>
                      <td className="py-2 text-right tabular-nums text-muted-foreground">{t.n}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-base font-bold">Departments &amp; staff strength</h2>
            <Link to="/salary" className="text-xs font-semibold text-primary hover:underline">
              Open <ArrowUpRight className="inline size-3" />
            </Link>
          </div>
          {departments.length === 0 ? (
            <p className="text-sm text-muted-foreground">Abhi koi staff salary entry nahi hai.</p>
          ) : (
            <ul className="space-y-2">
              {departments.map(([d, t]) => (
                <li
                  key={d}
                  className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2"
                >
                  <div>
                    <div className="text-sm font-semibold">{d}</div>
                    <div className="text-[11px] text-muted-foreground">
                      Strength {t.count} · Advance {fmt(t.advance)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold tabular-nums">{fmt(t.due - t.advance)}</div>
                    <div className="text-[11px] text-muted-foreground">Payable</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="mt-6 rounded-xl border border-border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-base font-bold">
            Employees <span className="text-muted-foreground">({empList.length})</span>
          </h2>
          <Link to="/employees" className="text-xs font-semibold text-primary hover:underline">
            Open profiles <ArrowUpRight className="inline size-3" />
          </Link>
        </div>
        {empList.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Abhi koi employee profile nahi — Employee Profiles page se add karein.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="py-2">Name</th>
                  <th className="py-2">Designation</th>
                  <th className="py-2">Department</th>
                  <th className="py-2">Mobile</th>
                  <th className="py-2 text-right">Salary</th>
                </tr>
              </thead>
              <tbody>
                {empList.map((e) => (
                  <tr key={e["id"] as string} className="border-b border-border/60 last:border-0">
                    <td className="py-2 font-medium">{String(e["name"] ?? "—")}</td>
                    <td className="py-2">{String(e["designation"] ?? "—")}</td>
                    <td className="py-2">{String(e["department"] ?? "—")}</td>
                    <td className="py-2 tabular-nums">{String(e["mobile_no"] ?? "—")}</td>
                    <td className="py-2 text-right font-semibold tabular-nums">
                      {fmt(num(e["current_salary"]))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <h2 className="mt-8 font-display text-lg font-bold">Registers</h2>
      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {MODULES.map(({ to, label, icon: Icon, text }) => (
          <Link
            key={to}
            to={to}
            className="group rounded-xl border border-border bg-gradient-to-br from-card to-muted/50 p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-md"
          >
            <span className="inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Icon className="size-5" />
            </span>
            <div className="mt-2 font-display font-semibold">{label}</div>
            <div className="text-xs text-muted-foreground">{text}</div>
          </Link>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <TrendingUp className="size-3.5 text-emerald-600" /> Receipts
        </span>
        <span className="inline-flex items-center gap-1">
          <TrendingDown className="size-3.5 text-destructive" /> Payments
        </span>
      </div>
    </div>
  );
}
