import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import {
  AddButton,
  CellInput,
  CsvButton,
  DeleteButton,
  ExcelButton,
  Paper,
  PrintButton,
  SheetTitle,
  ToolBar,
} from "@/components/sheet-ui";
import { Button } from "@/components/ui/button";
import { type Row, useRowMutations, useRows } from "@/lib/db";
import { useCompany } from "@/lib/company";
import { exportCsv, exportSheet, fmt, fmtDate, num, printBlock, type Cell } from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/demand")({
  head: () => ({
    meta: [
      { title: "Demand Sheet — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Site demand sheets with demand number, date, description, quantity, rate, amount and remarks — exportable to Excel and printable.",
      },
      { property: "og:title", content: "Demand Sheet — ALM Accounts Software" },
      { property: "og:description", content: "Editable material demand sheets with auto totals." },
    ],
  }),
  component: DemandSheet,
});

function DemandSheet() {
  const { company } = useCompany();
  const demandsQuery = useRows("demands", { orderBy: "created_at" });
  const demands: Row[] = demandsQuery.data ?? [];
  const demandMut = useRowMutations("demands");
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    if (!activeId && demands.length) setActiveId(demands[0]?.["id"] as string);
  }, [demands, activeId]);

  const active = demands.find((d) => d["id"] === activeId) ?? null;
  const itemsQuery = useRows("demand_items", {
    filter: activeId ? { demand_id: activeId } : { demand_id: "00000000-0000-0000-0000-000000000000" },
  });
  const items: Row[] = activeId ? (itemsQuery.data ?? []) : [];
  const itemMut = useRowMutations("demand_items");

  const amount = (r: Row) => num(r["qty"]) * num(r["rate"]);
  const total = items.reduce((a, r) => a + amount(r), 0);

  const sheetRows = (): Cell[][] => [
    [`${company.name} — ${company.project}`],
    ["Demand No:", String(active?.["demand_no"] ?? ""), `PROJECT: ${active?.["project"] ?? ""}`],
    ["Demand Date:", fmtDate(active?.["demand_date"] as string)],
    ["SR.NO", "DESCRIPTION", "Ref", "Qty", "Rate", "Amount", "REMARKS"],
    ...items.map((r, i) => [
      i + 1,
      String(r["description"] ?? ""),
      String(r["ref"] ?? ""),
      num(r["qty"]),
      num(r["rate"]),
      amount(r),
      String(r["remarks"] ?? ""),
    ]),
    ["", "Total", "", "", "", total, ""],
  ];

  return (
    <div>
      <ToolBar title="Demand Sheet" subtitle="Amount = Qty × Rate">
        <Button
          size="sm"
          onClick={() =>
            demandMut.insert.mutate(
              { demand_no: String(demands.length + 1), demand_date: null, project: "" },
              { onSuccess: (d: Row) => setActiveId(d["id"] as string) },
            )
          }
        >
          New Demand
        </Button>
        {active ? (
          <>
            <AddButton
              label="Add Item"
              onClick={() =>
                itemMut.insert.mutate({
                  demand_id: activeId,
                  description: "",
                  ref: "",
                  qty: 0,
                  rate: 0,
                  remarks: "",
                  sort_index: items.length + 1,
                })
              }
            />
            <ExcelButton
              onClick={() =>
                exportSheet(`${company.short}-Demand-${active["demand_no"]}`, sheetRows(), {
                  sheetName: "Demand",
                  colWidths: [8, 45, 10, 8, 12, 14, 26],
                })
              }
            />
            <CsvButton onClick={() => exportCsv(`${company.short}-Demand-${active["demand_no"]}`, sheetRows())} />
            <PrintButton onClick={() => printBlock("demand-sheet", `${company.short} Demand Sheet`)} />
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                demandMut.remove.mutate(activeId as string);
                setActiveId(null);
              }}
            >
              Delete Demand
            </Button>
          </>
        ) : null}
      </ToolBar>

      <div className="no-print mb-4 flex flex-wrap gap-2">
        {demands.map((d) => (
          <button
            key={d["id"] as string}
            onClick={() => setActiveId(d["id"] as string)}
            className={`rounded-md border px-3 py-1.5 text-sm ${
              d["id"] === activeId
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card"
            }`}
          >
            Demand {String(d["demand_no"] ?? "-")}
          </button>
        ))}
      </div>

      {active ? (
        <Paper id="demand-sheet">
          <SheetTitle lines={[`${company.name} — ${company.project}`]} />
          <table className="xl-table">
            <tbody>
              <tr>
                <th style={{ width: 120 }}>Demand No:</th>
                <td className="t-center" style={{ width: 260 }}>
                  <CellInput
                    align="center"
                    value={(active["demand_no"] as string) ?? ""}
                    onChange={(v) =>
                      demandMut.update.mutate({
                        id: active["id"] as string,
                        values: { demand_no: v },
                      })
                    }
                  />
                </td>
                <th colSpan={5}>
                  PROJECT:{" "}
                  <CellInput
                    align="center"
                    value={(active["project"] as string) ?? ""}
                    onChange={(v) =>
                      demandMut.update.mutate({
                        id: active["id"] as string,
                        values: { project: v },
                      })
                    }
                  />
                </th>
              </tr>
              <tr>
                <th>Demand Date:</th>
                <td className="t-center">
                  <CellInput
                    type="date"
                    align="center"
                    value={(active["demand_date"] as string) ?? ""}
                    onChange={(v) =>
                      demandMut.update.mutate({
                        id: active["id"] as string,
                        values: { demand_date: v || null },
                      })
                    }
                  />
                </td>
                <td colSpan={5} />
              </tr>
            </tbody>
          </table>

          <table className="xl-table mt-2">
            <thead>
              <tr>
                <th style={{ width: 60 }}>SR.NO</th>
                <th>DESCRIPTION</th>
                <th style={{ width: 80 }}>Ref</th>
                <th style={{ width: 70 }}>Qty</th>
                <th style={{ width: 100 }}>Rate</th>
                <th style={{ width: 110 }}>Amount</th>
                <th style={{ width: 180 }}>REMARKS</th>
                <th className="no-print" style={{ width: 44 }}>
                  —
                </th>
              </tr>
            </thead>
            <tbody>
              {items.map((r, i) => (
                <tr key={r["id"] as string}>
                  <td className="t-center">{i + 1}</td>
                  <td>
                    <CellInput
                      value={(r["description"] as string) ?? ""}
                      onChange={(v) =>
                        itemMut.update.mutate({
                          id: r["id"] as string,
                          values: { description: v },
                        })
                      }
                    />
                  </td>
                  <td>
                    <CellInput
                      value={(r["ref"] as string) ?? ""}
                      onChange={(v) =>
                        itemMut.update.mutate({ id: r["id"] as string, values: { ref: v } })
                      }
                    />
                  </td>
                  <td>
                    <CellInput
                      type="number"
                      align="center"
                      value={(r["qty"] as number) ?? 0}
                      onChange={(v) =>
                        itemMut.update.mutate({ id: r["id"] as string, values: { qty: num(v) } })
                      }
                    />
                  </td>
                  <td>
                    <CellInput
                      type="number"
                      align="right"
                      value={(r["rate"] as number) ?? 0}
                      onChange={(v) =>
                        itemMut.update.mutate({ id: r["id"] as string, values: { rate: num(v) } })
                      }
                    />
                  </td>
                  <td className="t-right font-semibold">{fmt(amount(r))}</td>
                  <td>
                    <CellInput
                      value={(r["remarks"] as string) ?? ""}
                      onChange={(v) =>
                        itemMut.update.mutate({ id: r["id"] as string, values: { remarks: v } })
                      }
                    />
                  </td>
                  <td className="no-print t-center">
                    <DeleteButton onClick={() => itemMut.remove.mutate(r["id"] as string)} />
                  </td>
                </tr>
              ))}
              <tr className="total-row">
                <td colSpan={5} className="t-center">
                  Total
                </td>
                <td className="t-right">{fmt(total)}</td>
                <td />
                <td className="no-print" />
              </tr>
            </tbody>
          </table>
        </Paper>
      ) : (
        <p className="text-sm text-muted-foreground">
          No demand sheet yet — click “New Demand” to create one.
        </p>
      )}
    </div>
  );
}
