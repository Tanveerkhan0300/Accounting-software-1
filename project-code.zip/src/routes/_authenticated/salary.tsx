import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import {
  AddButton,
  CellInput,
  CsvButton,
  DeleteButton,
  ExcelButton,
  Paper,
  PrintButton,
  SaveButton,
  SheetTitle,
  ToolBar,
} from "@/components/sheet-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { type Row, useRowMutations, useRows, useSetting } from "@/lib/db";
import { useCompany } from "@/lib/company";
import {
  currentPeriod,
  exportCsv,
  exportSheet,
  fmt,
  fmtDate,
  num,
  periodLabel,
  printBlock,
  type Cell,
} from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/salary")({
  head: () => ({
    meta: [
      { title: "Staff Salary Sheet — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Department-wise staff salary sheet with gross salary, days, due salary, advance and payable salary — separate Excel export and print per department.",
      },
      { property: "og:title", content: "Staff Salary Sheet — ALM Accounts Software" },
      {
        property: "og:description",
        content: "Department-wise salary sheets with automatic formulas and totals.",
      },
    ],
  }),
  component: SalarySheet,
});

const due = (r: Row) => (num(r["gross_salary"]) * num(r["days"])) / 30;
const payable = (r: Row) => due(r) - num(r["advance"]);

function SalarySheet() {
  const { company } = useCompany();
  const [period, setPeriod] = useState(currentPeriod());
  const [newDept, setNewDept] = useState("");
  const query = useRows("salary_entries", { filter: { period } });
  const rows: Row[] = query.data ?? [];
  const { insert, update, remove } = useRowMutations("salary_entries");
  // Departments are stored per month so a freshly added department stays
  // visible even before any staff row is entered in it.
  const deptStore = useSetting<Record<string, string[]>>("salary_departments", {});
  const savedDepts = deptStore.value[period] ?? [];

  const departments = useMemo(() => {
    const set = new Set<string>(savedDepts.filter(Boolean));
    rows.forEach((r) => {
      const d = String(r["department"] ?? "").trim();
      if (d) set.add(d);
    });
    return [...set];
  }, [rows, savedDepts]);

  const addDepartment = (name: string) => {
    const dept = name.trim();
    if (!dept) return;
    if (departments.some((d) => d.toLowerCase() === dept.toLowerCase())) {
      toast.error(`"${dept}" already exists for ${periodLabel(period)}`);
      return;
    }
    deptStore.save.mutate({ ...deptStore.value, [period]: [...savedDepts, dept] });
    toast.success(`Department "${dept}" added`);
  };

  const removeDepartment = (dept: string) => {
    deptStore.save.mutate({
      ...deptStore.value,
      [period]: savedDepts.filter((d) => d !== dept),
    });
  };

  const deptRows = (dept: string): Cell[][] => {
    const list = rows.filter((r) => String(r["department"] ?? "") === dept);
    return [
      [company.name],
      [company.project],
      [dept],
      [periodLabel(period)],
      [
        "S#",
        "Name",
        "Designation",
        "Joining Date",
        "Gross Salary",
        "Days",
        "Due Salary",
        "Advance",
        "Payable Salary",
        "Signature",
      ],
      ...list.map((r, i) => [
        i + 1,
        String(r["employee_name"] ?? ""),
        String(r["designation"] ?? ""),
        fmtDate(r["joining_date"] as string),
        num(r["gross_salary"]),
        num(r["days"]),
        due(r),
        num(r["advance"]),
        payable(r),
        "",
      ]),
      [
        "Total",
        "",
        "",
        "",
        list.reduce((a, r) => a + num(r["gross_salary"]), 0),
        "",
        list.reduce((a, r) => a + due(r), 0),
        list.reduce((a, r) => a + num(r["advance"]), 0),
        list.reduce((a, r) => a + payable(r), 0),
        "",
      ],
      [],
      ["Prepared by:", "", "", "", "", "", "", "", "Reviewed by:"],
      ["Accountant", "", "", "", "", "", "", "", "Project Manager"],
    ];
  };

  const addRow = (dept: string) =>
    insert.mutate({
      period,
      department: dept,
      employee_name: "",
      designation: "",
      joining_date: null,
      gross_salary: 0,
      days: 30,
      advance: 0,
      sort_index: rows.length + 1,
    });

  return (
    <div>
      <ToolBar
        title="Staff Salary Sheet"
        subtitle="Due Salary = Gross ÷ 30 × Days · Payable = Due − Advance"
      >
        <Input
          type="month"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="h-8 w-40"
        />
        <SaveButton />
      </ToolBar>

      <div className="no-print mb-2 flex flex-wrap items-end gap-2 rounded-lg border border-border bg-card p-4">
        <label className="text-sm">
          <span className="text-muted-foreground">Department / Team ka naam</span>
          <Input
            value={newDept}
            placeholder="e.g. Office, Survey Team, Camp and Site"
            onChange={(e) => setNewDept(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                addDepartment(newDept);
                setNewDept("");
              }
            }}
            className="mt-1 h-8 w-64"
          />
        </label>
        <AddButton
          label="Add Department"
          onClick={() => {
            addDepartment(newDept);
            setNewDept("");
          }}
        />
      </div>

      {departments.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          {periodLabel(period)} ke liye koi department nahi — upar naam likh kar "Add Department"
          dabayein.
        </p>
      ) : null}

      {departments.map((dept) => {
        const list = rows.filter((r) => String(r["department"] ?? "") === dept);
        const id = `salary-${dept.replace(/\s+/g, "-").toLowerCase()}`;
        return (
          <section key={dept} className="mt-8">
            <ToolBar title={dept} subtitle={`Salary sheet for ${periodLabel(period)}`}>
              <AddButton label="Add Staff" onClick={() => addRow(dept)} />
              <SaveButton />
              <ExcelButton
                onClick={() =>
                  exportSheet(`${company.short}-${dept}-${periodLabel(period)}`, deptRows(dept), {
                    sheetName: dept.slice(0, 28),
                    colWidths: [6, 22, 20, 14, 14, 8, 14, 12, 16, 18],
                  })
                }
              />
              <CsvButton
                onClick={() => exportCsv(`${company.short}-${dept}-${periodLabel(period)}`, deptRows(dept))}
              />
              <PrintButton onClick={() => printBlock(id, `${dept} Salary Sheet`)} />
              {list.length === 0 ? (
                <Button variant="outline" size="sm" onClick={() => removeDepartment(dept)}>
                  Remove Department
                </Button>
              ) : null}
            </ToolBar>

            <Paper id={id}>
              <SheetTitle
                lines={[
                  company.name,
                  company.project,
                  dept,
                  `For The Month of ${periodLabel(period)}`,
                ]}
              />
              <table className="xl-table">
                <thead>
                  <tr>
                    <th style={{ width: 40 }}>S#</th>
                    <th>Name</th>
                    <th style={{ width: 130 }}>Designation</th>
                    <th style={{ width: 120 }}>Joining Date</th>
                    <th style={{ width: 110 }}>Gross Salary</th>
                    <th style={{ width: 60 }}>Days</th>
                    <th style={{ width: 110 }}>Due Salary</th>
                    <th style={{ width: 100 }}>Advance</th>
                    <th style={{ width: 120 }}>Payable Salary</th>
                    <th style={{ width: 130 }}>Signature</th>
                    <th className="no-print" style={{ width: 44 }}>
                      —
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((r, i) => (
                    <tr key={r["id"] as string}>
                      <td className="t-center">{i + 1}</td>
                      <td>
                        <CellInput
                          value={(r["employee_name"] as string) ?? ""}
                          placeholder="Employee name"
                          onChange={(v) =>
                            update.mutate({
                              id: r["id"] as string,
                              values: { employee_name: v },
                            })
                          }
                        />
                      </td>
                      <td>
                        <CellInput
                          value={(r["designation"] as string) ?? ""}
                          onChange={(v) =>
                            update.mutate({ id: r["id"] as string, values: { designation: v } })
                          }
                        />
                      </td>
                      <td>
                        <CellInput
                          type="date"
                          value={(r["joining_date"] as string) ?? ""}
                          onChange={(v) =>
                            update.mutate({
                              id: r["id"] as string,
                              values: { joining_date: v || null },
                            })
                          }
                        />
                      </td>
                      <td>
                        <CellInput
                          type="number"
                          align="right"
                          value={(r["gross_salary"] as number) ?? 0}
                          onChange={(v) =>
                            update.mutate({
                              id: r["id"] as string,
                              values: { gross_salary: num(v) },
                            })
                          }
                        />
                      </td>
                      <td>
                        <CellInput
                          type="number"
                          align="center"
                          value={(r["days"] as number) ?? 30}
                          onChange={(v) =>
                            update.mutate({ id: r["id"] as string, values: { days: num(v) } })
                          }
                        />
                      </td>
                      <td className="t-right">{fmt(due(r))}</td>
                      <td>
                        <CellInput
                          type="number"
                          align="right"
                          value={(r["advance"] as number) ?? 0}
                          onChange={(v) =>
                            update.mutate({ id: r["id"] as string, values: { advance: num(v) } })
                          }
                        />
                      </td>
                      <td className="t-right font-semibold">{fmt(payable(r))}</td>
                      <td />
                      <td className="no-print t-center">
                        <DeleteButton onClick={() => remove.mutate(r["id"] as string)} />
                      </td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td colSpan={4} className="t-center">
                      Total
                    </td>
                    <td className="t-right">
                      {fmt(list.reduce((a, r) => a + num(r["gross_salary"]), 0))}
                    </td>
                    <td />
                    <td className="t-right">{fmt(list.reduce((a, r) => a + due(r), 0))}</td>
                    <td className="t-right">
                      {fmt(list.reduce((a, r) => a + num(r["advance"]), 0))}
                    </td>
                    <td className="t-right">{fmt(list.reduce((a, r) => a + payable(r), 0))}</td>
                    <td />
                    <td className="no-print" />
                  </tr>
                </tbody>
              </table>
              <div className="mt-6 flex justify-between text-xs font-semibold">
                <div>
                  Prepared by:
                  <div className="font-normal">Accountant</div>
                </div>
                <div className="text-right">
                  Reviewed by:
                  <div className="font-normal">Project Manager</div>
                </div>
              </div>
            </Paper>
          </section>
        );
      })}
    </div>
  );
}
