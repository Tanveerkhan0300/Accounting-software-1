import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import {
  CellInput,
  CsvButton,
  ExcelButton,
  Paper,
  PrintButton,
  SheetTitle,
  ToolBar,
} from "@/components/sheet-ui";
import { Button } from "@/components/ui/button";
import { type Row, useRowMutations, useRows } from "@/lib/db";
import { useCompany } from "@/lib/company";
import { exportCsv, exportSheet, fmt, fmtDate, num, printBlock, type Cell } from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/employees")({
  head: () => ({
    meta: [
      { title: "Employee Profiles — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Employee profile records with father name, designation, qualification, CNIC, contacts, address, salary and terms — exportable and printable.",
      },
      { property: "og:title", content: "Employee Profiles — ALM Accounts Software" },
      { property: "og:description", content: "Editable ALM employee profile register." },
    ],
  }),
  component: Employees,
});

const TERMS = [
  "1. If the Employee wants to leave the job, the Employee will have to give prior notice before leaving the job for replacement of other Employee on the same position.",
  "2. If Company terminates the Employee, the Company will have to give prior notice before Terminating the Employee from the Job.",
];

const FIELDS: { key: string; label: string; type?: "date" | "number" }[] = [
  { key: "employee_name", label: "Employee Name:" },
  { key: "father_name", label: "Father Name:" },
  { key: "designation", label: "Designation:" },
  { key: "qualification", label: "Qualification:" },
  { key: "experience", label: "Experience:" },
  { key: "cnic_no", label: "CNIC No:" },
  { key: "mobile_no", label: "Mobile No:" },
  { key: "kin_contact_no", label: "Next to kin Contact No:" },
  { key: "relation", label: "Relation:" },
  { key: "department", label: "Department:" },
  { key: "camp_site", label: "Camp / Site:" },
  { key: "reference_by", label: "Reference By:" },
];

function Employees() {
  const { company } = useCompany();
  const query = useRows("employees", { orderBy: "created_at" });
  const list: Row[] = query.data ?? [];
  const { insert, update, remove } = useRowMutations("employees");
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    if (!activeId && list.length) setActiveId(list[0]?.["id"] as string);
  }, [list, activeId]);

  const emp = list.find((e) => e["id"] === activeId) ?? null;
  const set = (key: string, value: unknown) =>
    emp && update.mutate({ id: emp["id"] as string, values: { [key]: value } });

  const profileRows = (): Cell[][] =>
    emp
      ? [
          [company.name],
          [company.project],
          ["EMPLOYEE PROFILE"],
          [],
          ...FIELDS.map((f) => [f.label, String(emp[f.key] ?? "")]),
          ["Joining Date", fmtDate(emp["joining_date"] as string)],
          ["i. Current Salary", num(emp["current_salary"])],
          ["ii. Revised", num(emp["revised_salary"])],
          ["Revised Date:", fmtDate(emp["revised_date"] as string)],
          ["Present Address:", "Village", "Tehsil", "District"],
          ["", String(emp["village"] ?? ""), String(emp["tehsil"] ?? ""), String(emp["district"] ?? "")],
          ["Job Description:", String(emp["job_description"] ?? "")],
          ["Terms and Conditions:", TERMS[0] ?? ""],
          ["", TERMS[1] ?? ""],
        ]
      : [];

  const listRows = (): Cell[][] => [
    [`${company.name} — Employee Register`],
    [
      "S#",
      "Employee Name",
      "Father Name",
      "Designation",
      "Department",
      "Camp / Site",
      "CNIC No",
      "Mobile No",
      "Joining Date",
      "Current Salary",
    ],
    ...list.map((e, i) => [
      i + 1,
      String(e["employee_name"] ?? ""),
      String(e["father_name"] ?? ""),
      String(e["designation"] ?? ""),
      String(e["department"] ?? ""),
      String(e["camp_site"] ?? ""),
      String(e["cnic_no"] ?? ""),
      String(e["mobile_no"] ?? ""),
      fmtDate(e["joining_date"] as string),
      num(e["current_salary"]),
    ]),
  ];

  return (
    <div>
      <ToolBar title="Employee Profiles" subtitle="Create a profile, then fill every field">
        <Button
          size="sm"
          onClick={() =>
            insert.mutate({ employee_name: "" }, { onSuccess: (d: Row) => setActiveId(d["id"] as string) })
          }
        >
          New Profile
        </Button>
        <ExcelButton label="Export Register" onClick={() => exportSheet(`${company.short}-Employee-Register`, listRows(), { sheetName: "Employees", colWidths: [6, 22, 22, 20, 18, 18, 20, 16, 14, 14] })} />
        <CsvButton onClick={() => exportCsv(`${company.short}-Employee-Register`, listRows())} />
        {emp ? (
          <>
            <ExcelButton
              label="Export This Profile"
              onClick={() =>
                exportSheet(
                  `${company.short}-Profile-${String(emp["employee_name"] || "employee")}`,
                  profileRows(),
                  { sheetName: "Profile", colWidths: [26, 34, 22, 22] },
                )
              }
            />
            <PrintButton onClick={() => printBlock("employee-profile", `${company.short} Employee Profile`)} />
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                remove.mutate(emp["id"] as string);
                setActiveId(null);
              }}
            >
              Delete Profile
            </Button>
          </>
        ) : null}
      </ToolBar>

      <div className="no-print mb-4 flex flex-wrap gap-2">
        {list.map((e) => (
          <button
            key={e["id"] as string}
            onClick={() => setActiveId(e["id"] as string)}
            className={`rounded-md border px-3 py-1.5 text-sm ${
              e["id"] === activeId
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card"
            }`}
          >
            {String(e["employee_name"] || "Untitled")}
          </button>
        ))}
      </div>

      {emp ? (
        <Paper id="employee-profile">
          <SheetTitle
            lines={[company.name, company.project, "EMPLOYEE PROFILE"]}
          />
          <table className="xl-table">
            <tbody>
              {FIELDS.map((f, idx) => (
                <tr key={f.key}>
                  <th style={{ width: 200, textAlign: "left" }}>{f.label}</th>
                  <td>
                    <CellInput
                      value={(emp[f.key] as string) ?? ""}
                      onChange={(v) => set(f.key, v)}
                    />
                  </td>
                  {idx === 0 ? (
                    <>
                      <th style={{ width: 150 }}>Joining Date</th>
                      <td style={{ width: 150 }}>
                        <CellInput
                          type="date"
                          value={(emp["joining_date"] as string) ?? ""}
                          onChange={(v) => set("joining_date", v || null)}
                        />
                      </td>
                    </>
                  ) : idx === 1 ? (
                    <>
                      <th>i. Current Salary</th>
                      <td>
                        <CellInput
                          type="number"
                          align="right"
                          value={(emp["current_salary"] as number) ?? 0}
                          onChange={(v) => set("current_salary", num(v))}
                        />
                      </td>
                    </>
                  ) : idx === 2 ? (
                    <>
                      <th>ii. Revised</th>
                      <td>
                        <CellInput
                          type="number"
                          align="right"
                          value={(emp["revised_salary"] as number) ?? 0}
                          onChange={(v) => set("revised_salary", num(v))}
                        />
                      </td>
                    </>
                  ) : idx === 3 ? (
                    <>
                      <th>Revised Date:</th>
                      <td>
                        <CellInput
                          type="date"
                          value={(emp["revised_date"] as string) ?? ""}
                          onChange={(v) => set("revised_date", v || null)}
                        />
                      </td>
                    </>
                  ) : (
                    <>
                      <td />
                      <td />
                    </>
                  )}
                </tr>
              ))}
              <tr>
                <th style={{ textAlign: "left" }}>Present Address:</th>
                <td colSpan={3}>
                  <table className="xl-table">
                    <thead>
                      <tr>
                        <th>Village</th>
                        <th>Tehsil</th>
                        <th>District</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <CellInput
                            align="center"
                            value={(emp["village"] as string) ?? ""}
                            onChange={(v) => set("village", v)}
                          />
                        </td>
                        <td>
                          <CellInput
                            align="center"
                            value={(emp["tehsil"] as string) ?? ""}
                            onChange={(v) => set("tehsil", v)}
                          />
                        </td>
                        <td>
                          <CellInput
                            align="center"
                            value={(emp["district"] as string) ?? ""}
                            onChange={(v) => set("district", v)}
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <th style={{ textAlign: "left" }}>Job Description:</th>
                <td colSpan={3}>
                  <textarea
                    rows={3}
                    value={(emp["job_description"] as string) ?? ""}
                    onChange={(e) => set("job_description", e.target.value)}
                    className="w-full resize-y bg-transparent px-1 py-0.5 outline-none focus:bg-accent/60"
                  />
                </td>
              </tr>
              <tr>
                <th style={{ textAlign: "left" }}>Terms and Conditions:</th>
                <td colSpan={3} className="space-y-1 text-xs">
                  {TERMS.map((t) => (
                    <p key={t}>{t}</p>
                  ))}
                </td>
              </tr>
            </tbody>
          </table>
          <div className="mt-10 flex justify-between text-xs font-semibold">
            <div>____________________<div>Applicant (Signature)</div></div>
            <div>____________________<div>Admin Manager</div></div>
            <div>____________________<div>Project Manager</div></div>
          </div>
        </Paper>
      ) : (
        <p className="text-sm text-muted-foreground">
          No profile yet — click “New Profile” to add your first employee.
        </p>
      )}

      <section className="mt-10">
        <h2 className="no-print mb-2 font-display text-lg font-bold">Employee Register</h2>
        <Paper id="employee-register">
          <table className="xl-table">
            <thead>
              <tr>
                <th style={{ width: 44 }}>S#</th>
                <th>Employee Name</th>
                <th>Designation</th>
                <th>Department</th>
                <th>CNIC No</th>
                <th>Mobile No</th>
                <th style={{ width: 110 }}>Joining Date</th>
                <th style={{ width: 110 }}>Current Salary</th>
              </tr>
            </thead>
            <tbody>
              {list.map((e, i) => (
                <tr key={e["id"] as string}>
                  <td className="t-center">{i + 1}</td>
                  <td>{String(e["employee_name"] ?? "")}</td>
                  <td>{String(e["designation"] ?? "")}</td>
                  <td>{String(e["department"] ?? "")}</td>
                  <td>{String(e["cnic_no"] ?? "")}</td>
                  <td>{String(e["mobile_no"] ?? "")}</td>
                  <td className="t-center">{fmtDate(e["joining_date"] as string)}</td>
                  <td className="t-right">{fmt(num(e["current_salary"]))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Paper>
      </section>
    </div>
  );
}
