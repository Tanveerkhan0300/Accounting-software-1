import { createFileRoute } from "@tanstack/react-router";
import { X } from "lucide-react";
import { Fragment, useState } from "react";

import {
  AddButton,
  CellInput,
  CsvButton,
  DeleteButton,
  ExcelButton,
  Paper,
  PrintButton,
  SheetTitle,
  ToolBar,
} from "@/components/sheet-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { type Row, useRowMutations, useRows, useSetting } from "@/lib/db";
import { useCompany } from "@/lib/company";
import {
  currentPeriod,
  exportCsv,
  exportSheet,
  fmt,
  num,
  periodLabel,
  printBlock,
  type Cell,
} from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/advance")({
  head: () => ({
    meta: [
      { title: "Advance Salaries — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Employees advance salaries working: opening balance, month-wise advances and adjustments with closing advance salaries, Excel export and print.",
      },
      { property: "og:title", content: "Advance Salaries — ALM Accounts Software" },
      { property: "og:description", content: "Month-wise advance salary register with auto closing." },
    ],
  }),
  component: Advance,
});

type Vals = Record<string, { amt?: number; adj?: number }>;
type Settings = { periods: string[] };

function Advance() {
  const { company } = useCompany();
  const settings = useSetting<Settings>("advance_periods", { periods: [] });
  const periods = settings.value.periods ?? [];
  const query = useRows("advance_rows");
  const rows: Row[] = query.data ?? [];
  const { insert, update, remove } = useRowMutations("advance_rows");
  const [newPeriod, setNewPeriod] = useState(currentPeriod());

  const vals = (r: Row): Vals => (r["values"] ?? {}) as Vals;
  const closing = (r: Row) =>
    num(r["opening"]) +
    periods.reduce((a, p) => a + num(vals(r)[p]?.amt) - num(vals(r)[p]?.adj), 0);

  const setCell = (r: Row, period: string, key: "amt" | "adj", value: number) => {
    const next: Vals = { ...vals(r), [period]: { ...(vals(r)[period] ?? {}), [key]: value } };
    update.mutate({ id: r["id"] as string, values: { values: next } });
  };

  const colTotal = (period: string, key: "amt" | "adj") =>
    rows.reduce((a, r) => a + num(vals(r)[period]?.[key]), 0);

  const sheetRows = (): Cell[][] => [
    ["Employees Advance Salaries Working"],
    [
      "Sr. No",
      "Name",
      "Camp Site",
      "Opening",
      ...periods.flatMap((p) => [periodLabel(p), `${periodLabel(p)} adj`]),
      "Closing Advance Salaries",
    ],
    ...rows.map((r, i) => [
      i + 1,
      String(r["name"] ?? ""),
      String(r["camp_site"] ?? ""),
      num(r["opening"]),
      ...periods.flatMap((p) => [num(vals(r)[p]?.amt), num(vals(r)[p]?.adj)]),
      closing(r),
    ]),
    [
      "Total",
      "",
      "",
      rows.reduce((a, r) => a + num(r["opening"]), 0),
      ...periods.flatMap((p) => [colTotal(p, "amt"), colTotal(p, "adj")]),
      rows.reduce((a, r) => a + closing(r), 0),
    ],
  ];

  return (
    <div>
      <ToolBar
        title="Employees Advance Salaries Working"
        subtitle="Closing = Opening + Advances − Adjustments"
      >
        <AddButton
          onClick={() =>
            insert.mutate({
              name: "",
              camp_site: "",
              opening: 0,
              values: {},
              sort_index: rows.length + 1,
            })
          }
        />
        <ExcelButton
          onClick={() =>
            exportSheet(`${company.short}-Advance-Salaries`, sheetRows(), {
              sheetName: "Advances",
              colWidths: [8, 28, 18, 12, ...periods.flatMap(() => [12, 12]), 18],
            })
          }
        />
        <CsvButton onClick={() => exportCsv(`${company.short}-Advance-Salaries`, sheetRows())} />
        <PrintButton onClick={() => printBlock("advance-sheet", `${company.short} Advance Salaries`)} />
      </ToolBar>

      <div className="no-print mb-4 flex flex-wrap items-end gap-2">
        <label className="text-sm">
          <span className="text-muted-foreground">Add month column</span>
          <Input
            type="month"
            value={newPeriod}
            onChange={(e) => setNewPeriod(e.target.value)}
            className="mt-1 h-8 w-40"
          />
        </label>
        <Button
          size="sm"
          onClick={() => {
            if (!newPeriod || periods.includes(newPeriod)) return;
            settings.save.mutate({ periods: [...periods, newPeriod].sort() });
          }}
        >
          Add Month
        </Button>
        <div className="flex flex-wrap gap-1">
          {periods.map((p) => (
            <span
              key={p}
              className="inline-flex items-center gap-1 rounded-md border border-border bg-card px-2 py-1 text-xs"
            >
              {periodLabel(p)}
              <button
                type="button"
                onClick={() =>
                  settings.save.mutate({ periods: periods.filter((x) => x !== p) })
                }
                className="text-destructive"
                title="Remove month"
              >
                <X className="size-3" />
              </button>
            </span>
          ))}
        </div>
      </div>

      <Paper id="advance-sheet">
        <SheetTitle
          lines={[
            company.name,
            "Employees Advance Salaries Working",
          ]}
        />
        <table className="xl-table">
          <thead>
            <tr>
              <th style={{ width: 50 }}>Sr. No</th>
              <th style={{ width: 200 }}>Name</th>
              <th style={{ width: 140 }}>Camp Site</th>
              <th style={{ width: 100 }}>Opening</th>
              {periods.map((p) => (
                <th key={p} colSpan={2}>
                  {periodLabel(p)}
                </th>
              ))}
              <th style={{ width: 140 }}>Closing Advance Salaries</th>
              <th className="no-print" style={{ width: 44 }}>
                —
              </th>
            </tr>
            <tr>
              <th colSpan={4} />
              {periods.map((p) => (
                <Fragment key={p}>
                  <th style={{ width: 100 }}>Advance</th>
                  <th style={{ width: 100 }}>Adjustment</th>
                </Fragment>
              ))}
              <th />
              <th className="no-print" />
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r["id"] as string}>
                <td className="t-center">{i + 1}</td>
                <td>
                  <CellInput
                    value={(r["name"] as string) ?? ""}
                    onChange={(v) => update.mutate({ id: r["id"] as string, values: { name: v } })}
                  />
                </td>
                <td>
                  <CellInput
                    value={(r["camp_site"] as string) ?? ""}
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { camp_site: v } })
                    }
                  />
                </td>
                <td>
                  <CellInput
                    type="number"
                    align="right"
                    value={(r["opening"] as number) ?? 0}
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { opening: num(v) } })
                    }
                  />
                </td>
                {periods.map((p) => (
                  <Fragment key={p}>
                    <td>
                      <CellInput
                        type="number"
                        align="right"
                        value={num(vals(r)[p]?.amt)}
                        onChange={(v) => setCell(r, p, "amt", num(v))}
                      />
                    </td>
                    <td>
                      <CellInput
                        type="number"
                        align="right"
                        value={num(vals(r)[p]?.adj)}
                        onChange={(v) => setCell(r, p, "adj", num(v))}
                      />
                    </td>
                  </Fragment>
                ))}
                <td className="t-right font-semibold">{fmt(closing(r))}</td>
                <td className="no-print t-center">
                  <DeleteButton onClick={() => remove.mutate(r["id"] as string)} />
                </td>
              </tr>
            ))}
            <tr className="total-row">
              <td colSpan={3} className="t-center">
                Total
              </td>
              <td className="t-right">{fmt(rows.reduce((a, r) => a + num(r["opening"]), 0))}</td>
              {periods.map((p) => (
                <Fragment key={p}>
                  <td className="t-right">{fmt(colTotal(p, "amt"))}</td>
                  <td className="t-right">{fmt(colTotal(p, "adj"))}</td>
                </Fragment>
              ))}
              <td className="t-right">{fmt(rows.reduce((a, r) => a + closing(r), 0))}</td>
              <td className="no-print" />
            </tr>
          </tbody>
        </table>
      </Paper>
    </div>
  );
}
