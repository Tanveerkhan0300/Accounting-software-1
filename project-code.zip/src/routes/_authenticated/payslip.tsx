import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

import { CsvButton, ExcelButton, Paper, PrintButton, ToolBar } from "@/components/sheet-ui";
import { Input } from "@/components/ui/input";
import { type Row, useRows } from "@/lib/db";
import { useCompany } from "@/lib/company";
import {
  currentPeriod,
  exportCsv,
  exportSheet,
  fmt,
  fmtDate,
  num,
  periodLabel,
  printBlock,
  rupeesInWords,
  type Cell,
} from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/payslip")({
  head: () => ({
    meta: [
      { title: "Salary Payslip — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Employee salary payslip with basic salary, due salary, advance deduction, net pay and amount in words — printable and exportable.",
      },
      { property: "og:title", content: "Salary Payslip — ALM Accounts Software" },
      { property: "og:description", content: "Print ALM employee payslips per month." },
    ],
  }),
  component: Payslip,
});

function Payslip() {
  const { company } = useCompany();
  const [period, setPeriod] = useState(currentPeriod());
  const query = useRows("salary_entries", { filter: { period } });
  const rows: Row[] = query.data ?? [];
  const [activeId, setActiveId] = useState<string | null>(null);
  const r = rows.find((x) => x["id"] === activeId) ?? rows[0] ?? null;

  const gross = num(r?.["gross_salary"]);
  const days = num(r?.["days"]);
  const dueSalary = (gross * days) / 30;
  const advance = num(r?.["advance"]);
  const net = dueSalary - advance;

  const sheetRows = (): Cell[][] => [
    [company.name],
    [company.project],
    ["EMPLOYEES SALARY PAYSLIP"],
    [],
    ["Employee name:", String(r?.["employee_name"] ?? ""), "Date of Joining:", fmtDate(r?.["joining_date"] as string)],
    ["Designation:", String(r?.["designation"] ?? ""), "Pay Period:", periodLabel(period)],
    ["Department:", String(r?.["department"] ?? ""), "Worked Days:", days],
    ["", "", "Month:", periodLabel(period)],
    [],
    ["Earnings", "Amount", "Deductions", "Amount"],
    ["Basic Salary", gross, "Due Salary", dueSalary],
    ["", "", "Advance Salary", advance],
    ["", "", "Net Pay", net],
    [],
    ["", "", "", net],
    [rupeesInWords(net)],
    [],
    ["Accountant Signature", "", "Employee Signature"],
  ];

  return (
    <div>
      <ToolBar title="Employees Salary Payslip" subtitle="Built from the salary sheet of the month">
        <Input
          type="month"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="h-8 w-40"
        />
        {r ? (
          <>
            <ExcelButton
              onClick={() =>
                exportSheet(
                  `${company.short}-Payslip-${String(r["employee_name"] || "employee")}-${periodLabel(period)}`,
                  sheetRows(),
                  { sheetName: "Payslip", colWidths: [26, 20, 22, 18] },
                )
              }
            />
            <CsvButton
              onClick={() =>
                exportCsv(
                  `${company.short}-Payslip-${String(r["employee_name"] || "employee")}-${periodLabel(period)}`,
                  sheetRows(),
                )
              }
            />
            <PrintButton onClick={() => printBlock("payslip", `${company.short} Payslip`)} />
          </>
        ) : null}
      </ToolBar>

      <div className="no-print mb-4 flex flex-wrap gap-2">
        {rows.map((x) => (
          <button
            key={x["id"] as string}
            onClick={() => setActiveId(x["id"] as string)}
            className={`rounded-md border px-3 py-1.5 text-sm ${
              x["id"] === (r?.["id"] ?? null)
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card"
            }`}
          >
            {String(x["employee_name"] || "Unnamed")}
          </button>
        ))}
      </div>

      {r ? (
        <Paper id="payslip">
          <div className="mb-3 text-center">
            <div className="doc-title text-base font-bold">{company.name}</div>
            <div className="doc-title text-base font-bold">CHITRAL ROADS (ALM) PROJECT</div>
            <div className="doc-title text-sm font-semibold">EMPLOYEES SALARY PAYSLIP</div>
          </div>

          <table className="xl-table">
            <tbody>
              <tr>
                <th style={{ width: 170, textAlign: "left" }}>Employee name:</th>
                <td>{String(r["employee_name"] ?? "")}</td>
                <th style={{ width: 150, textAlign: "left" }}>Date of Joining:</th>
                <td style={{ width: 150 }}>{fmtDate(r["joining_date"] as string)}</td>
              </tr>
              <tr>
                <th style={{ textAlign: "left" }}>Designation:</th>
                <td>{String(r["designation"] ?? "")}</td>
                <th style={{ textAlign: "left" }}>Pay Period:</th>
                <td>{periodLabel(period)}</td>
              </tr>
              <tr>
                <th style={{ textAlign: "left" }}>Department:</th>
                <td>{String(r["department"] ?? "")}</td>
                <th style={{ textAlign: "left" }}>Worked Days:</th>
                <td>{days}</td>
              </tr>
              <tr>
                <td />
                <td />
                <th style={{ textAlign: "left" }}>Month:</th>
                <td>{periodLabel(period)}</td>
              </tr>
            </tbody>
          </table>

          <table className="xl-table mt-4">
            <thead>
              <tr>
                <th>Earnings</th>
                <th style={{ width: 160 }}>Amount</th>
                <th>Deductions</th>
                <th style={{ width: 160 }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Basic Salary</td>
                <td className="t-right">{fmt(gross)}</td>
                <td>Due Salary</td>
                <td className="t-right">{fmt(dueSalary)}</td>
              </tr>
              <tr>
                <td />
                <td />
                <td>Advance Salary</td>
                <td className="t-right">{fmt(advance)}</td>
              </tr>
              <tr className="total-row">
                <td />
                <td />
                <td className="t-right">Net Pay</td>
                <td className="t-right">{fmt(net)}</td>
              </tr>
            </tbody>
          </table>

          <div className="mt-6 text-right">
            <div className="font-semibold">{fmt(net)}</div>
            <div className="text-sm font-bold">{rupeesInWords(net)}</div>
          </div>

          <div className="mt-16 flex justify-between text-sm">
            <div>
              Accountant Signature
              <div className="mt-6">_______________________</div>
            </div>
            <div className="text-right">
              Employee Signature
              <div className="mt-6">_______________________</div>
            </div>
          </div>
        </Paper>
      ) : (
        <p className="text-sm text-muted-foreground">
          No salary rows for {periodLabel(period)} yet — add them in the Staff Salary Sheet first.
        </p>
      )}
    </div>
  );
}
