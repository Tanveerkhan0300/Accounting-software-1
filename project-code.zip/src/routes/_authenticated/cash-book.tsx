import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

import {
  AddButton,
  CellInput,
  CsvButton,
  DeleteButton,
  ExcelButton,
  Paper,
  PrintButton,
  SaveButton,
  SheetTitle,
  StatChip,
  ToolBar,
} from "@/components/sheet-ui";
import { Input } from "@/components/ui/input";
import { type Row, useRowMutations, useRows, useSetting } from "@/lib/db";
import { useCompany } from "@/lib/company";
import {
  currentPeriod,
  exportCsv,
  exportSheet,
  fmt,
  fmtDate,
  num,
  periodLabel,
  printBlock,
  type Cell,
} from "@/lib/sheet";

export const Route = createFileRoute("/_authenticated/cash-book")({
  head: () => ({
    meta: [
      { title: "Cash Book — ALM Accounts Software" },
      {
        name: "description",
        content:
          "Month-wise cash book expense detail with receipts, payments, running balance, Excel export and print.",
      },
      { property: "og:title", content: "Cash Book — ALM Accounts Software" },
      {
        property: "og:description",
        content: "Editable month-wise cash book register with automatic running balance.",
      },
    ],
  }),
  component: CashBook,
});

type Settings = Record<string, string>;

function CashBook() {
  const { company } = useCompany();
  const [period, setPeriod] = useState(currentPeriod());
  const cashQuery = useRows("cash_book_entries", { filter: { period } });
  const rows: Row[] = cashQuery.data ?? [];
  const { insert, update, remove } = useRowMutations("cash_book_entries");
  const allQuery = useRows("cash_book_entries", { orderBy: "period" });
  const settings = useSetting<Settings>("cash_book_dates", {});
  const sheetDate = settings.value[period] ?? "";

  // Previous months ka closing balance = is month ka opening balance (automatic).
  const opening = (allQuery.data ?? []).reduce(
    (a, r) =>
      String(r["period"] ?? "") && String(r["period"]) < period
        ? a + num(r["receipts"]) - num(r["payments"])
        : a,
    0,
  );

  let running = opening;
  const withBalance: (Row & { balance: number })[] = rows.map((r) => {
    running += num(r["receipts"]) - num(r["payments"]);
    return { ...r, balance: running };
  });
  const totalReceipts = rows.reduce((a, r) => a + num(r["receipts"]), 0);
  const totalPayments = rows.reduce((a, r) => a + num(r["payments"]), 0);


  // Month-wise history: every month that has entries, with its own totals.
  const history = (() => {
    const map = new Map<string, { receipts: number; payments: number; count: number }>();
    (allQuery.data ?? []).forEach((r) => {
      const p = String(r["period"] ?? "");
      if (!p) return;
      const cur = map.get(p) ?? { receipts: 0, payments: 0, count: 0 };
      cur.receipts += num(r["receipts"]);
      cur.payments += num(r["payments"]);
      cur.count += 1;
      map.set(p, cur);
    });
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  })();

  const addRow = () =>
    insert.mutate({
      period,
      entry_date: null,
      description: "",
      receipts: 0,
      payments: 0,
      remarks: "",
      sort_index: rows.length + 1,
    });

  const sheetRows = (): Cell[][] => [
    [company.name],
    [company.project],
    [`Cash Book Expense Detail — ${periodLabel(period)}`],
    ["", "", "", "", "", `Dated: ${fmtDate(sheetDate)}`],
    [],
    ["S#", "Date", "Description", "Receipts", "Payments", "Balance", "Remarks"],
    ["", "", `Opening balance as on ${periodLabel(period)}`, "", "", opening, "Carried forward"],

    ...withBalance.map((r, i) => [
      i + 1,
      fmtDate(r["entry_date"] as string),
      String(r["description"] ?? ""),
      num(r["receipts"]),
      num(r["payments"]),
      r.balance,
      String(r["remarks"] ?? ""),
    ]),
    ["", "", "Total", totalReceipts, totalPayments, running, ""],
  ];

  const fileName = `${company.short}-Cash-Book-${periodLabel(period)}`;

  return (
    <div>
      <ToolBar title="Cash Book — Expense Detail">

        <Input
          type="month"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="h-8 w-40"
        />
        <AddButton onClick={addRow} />
        <SaveButton />
        <ExcelButton
          onClick={() =>
            exportSheet(fileName, sheetRows(), {
              sheetName: `Cash Book ${periodLabel(period)}`.slice(0, 28),
              colWidths: [6, 11, 60, 14, 14, 14, 22],
            })
          }
        />
        <CsvButton onClick={() => exportCsv(fileName, sheetRows())} />
        <PrintButton onClick={() => printBlock("cash-book-sheet", `${company.short} Cash Book ${periodLabel(period)}`)} />
      </ToolBar>

      <div className="no-print mb-4 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <StatChip label="Opening balance" value={fmt(opening)} tone="muted" />
        <StatChip label="Receipts" value={fmt(totalReceipts)} tone="positive" />
        <StatChip label="Payments" value={fmt(totalPayments)} tone="negative" />
        <StatChip label="Closing balance" value={fmt(running)} tone="primary" />
        <StatChip label="Entries" value={String(rows.length)} tone="muted" />
      </div>

      <div className="no-print mb-4 rounded-xl border border-border bg-card p-4 shadow-sm">
        <div className="mb-2 font-display text-sm font-bold">Month-wise history</div>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground">Abhi koi month ka record nahi hai.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {history.map(([p, t]) => (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={`rounded-lg border px-3 py-2 text-left transition-colors ${
                  p === period
                    ? "border-primary bg-primary/10"
                    : "border-border bg-background hover:bg-accent/40"
                }`}
              >
                <div className="text-xs font-semibold">{periodLabel(p)}</div>
                <div className="text-[11px] tabular-nums text-muted-foreground">
                  R {fmt(t.receipts)} · P {fmt(t.payments)} · Bal {fmt(t.receipts - t.payments)}
                </div>
                <div className="text-[10px] text-muted-foreground">{t.count} entries</div>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="no-print mb-4 max-w-xs">
        <label className="text-sm">
          <span className="text-muted-foreground">Sheet dated</span>
          <input
            type="date"
            value={sheetDate}
            onChange={(e) =>
              settings.save.mutate({ ...settings.value, [period]: e.target.value })
            }
            className="mt-1 w-full rounded-md border border-input bg-card px-2 py-1.5"
          />
        </label>
      </div>

      <Paper id="cash-book-sheet">
        <SheetTitle
          lines={[
            company.name,
            company.project,
            `Cash Book Expense Detail — ${periodLabel(period)}`,
          ]}
        />
        <div className="mb-1 text-right text-xs font-semibold">
          Dated: {fmtDate(sheetDate) || "—"}
        </div>
        <table className="xl-table">
          <thead>
            <tr>
              <th style={{ width: 40 }}>S#</th>
              <th style={{ width: 92 }}>Date</th>
              <th style={{ minWidth: 420 }}>Description</th>
              <th style={{ width: 100 }}>Receipts</th>
              <th style={{ width: 100 }}>Payments</th>
              <th style={{ width: 100 }}>Balance</th>
              <th style={{ width: 130 }}>Remarks</th>
              <th className="no-print" style={{ width: 44 }}>
                —
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="bg-muted/40 font-medium">
              <td className="t-center">—</td>
              <td />
              <td>Opening balance as on {periodLabel(period)}</td>
              <td />
              <td />
              <td className="t-right">{fmt(opening)}</td>
              <td className="text-xs text-muted-foreground">Carried forward</td>
              <td className="no-print" />
            </tr>
            {withBalance.map((r, i) => (
              <tr key={r["id"] as string}>
                <td className="t-center">{i + 1}</td>
                <td>
                  <CellInput
                    type="date"
                    className="text-xs"
                    value={(r["entry_date"] as string) ?? ""}
                    onChange={(v) =>
                      update.mutate({
                        id: r["id"] as string,
                        values: { entry_date: v || null },
                      })
                    }
                  />
                </td>
                <td>
                  <CellInput
                    value={(r["description"] as string) ?? ""}
                    placeholder="Narration…"
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { description: v } })
                    }
                  />
                </td>
                <td>
                  <CellInput
                    type="number"
                    align="right"
                    value={(r["receipts"] as number) ?? 0}
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { receipts: num(v) } })
                    }
                  />
                </td>
                <td>
                  <CellInput
                    type="number"
                    align="right"
                    value={(r["payments"] as number) ?? 0}
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { payments: num(v) } })
                    }
                  />
                </td>
                <td className="t-right font-medium">{fmt(r.balance)}</td>
                <td>
                  <CellInput
                    value={(r["remarks"] as string) ?? ""}
                    onChange={(v) =>
                      update.mutate({ id: r["id"] as string, values: { remarks: v } })
                    }
                  />
                </td>
                <td className="no-print t-center">
                  <DeleteButton onClick={() => remove.mutate(r["id"] as string)} />
                </td>
              </tr>
            ))}
            <tr className="total-row">
              <td colSpan={3} className="t-center">
                Total
              </td>
              <td className="t-right">{fmt(totalReceipts)}</td>
              <td className="t-right">{fmt(totalPayments)}</td>
              <td className="t-right">{fmt(running)}</td>
              <td />
              <td className="no-print" />
            </tr>
          </tbody>
        </table>
        {rows.length === 0 ? (
          <p className="no-print mt-3 text-sm text-muted-foreground">
            {periodLabel(period)} ka koi entry nahi — "Add Row" se shuru karein (opening balance
            bhi khud pehli row me likh sakte hain).
          </p>
        ) : null}
      </Paper>
    </div>
  );
}
