import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { ToolBar } from "@/components/sheet-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCompany } from "@/lib/company";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Company Settings — Accounts Software" },
      {
        name: "description",
        content:
          "Edit the company name, short name and project title shown on every sheet, print and Excel export.",
      },
      { property: "og:title", content: "Company Settings — Accounts Software" },
      {
        property: "og:description",
        content: "Rename the company and project used across all accounts registers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const { company, save } = useCompany();
  const [short, setShort] = useState(company.short);
  const [name, setName] = useState(company.name);
  const [project, setProject] = useState(company.project);

  useEffect(() => {
    setShort(company.short);
    setName(company.name);
    setProject(company.project);
  }, [company.short, company.name, company.project]);

  const onSave = () => {
    save.mutate(
      { short, name, project },
      { onSuccess: () => toast.success("Company details saved") },
    );
  };

  return (
    <div>
      <ToolBar
        title="Company Settings"
        subtitle="Company aur project ka naam yahan badlein — har sheet, print aur Excel export me update ho jayega"
      />

      <div className="max-w-xl space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
        <label className="block text-sm">
          <span className="font-medium">Short name (sidebar logo)</span>
          <Input value={short} onChange={(e) => setShort(e.target.value)} className="mt-1" />
        </label>
        <label className="block text-sm">
          <span className="font-medium">Company name</span>
          <Input value={name} onChange={(e) => setName(e.target.value)} className="mt-1" />
        </label>
        <label className="block text-sm">
          <span className="font-medium">Project title</span>
          <Input value={project} onChange={(e) => setProject(e.target.value)} className="mt-1" />
        </label>
        <Button onClick={onSave} disabled={save.isPending}>
          {save.isPending ? "Saving…" : "Save company details"}
        </Button>
      </div>
    </div>
  );
}
