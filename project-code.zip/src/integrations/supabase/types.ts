export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      advance_rows: {
        Row: {
          camp_site: string
          created_at: string
          id: string
          name: string
          opening: number
          sort_index: number
          updated_at: string
          values: Json
        }
        Insert: {
          camp_site?: string
          created_at?: string
          id?: string
          name?: string
          opening?: number
          sort_index?: number
          updated_at?: string
          values?: Json
        }
        Update: {
          camp_site?: string
          created_at?: string
          id?: string
          name?: string
          opening?: number
          sort_index?: number
          updated_at?: string
          values?: Json
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      cash_book_entries: {
        Row: {
          created_at: string
          description: string
          entry_date: string | null
          id: string
          payments: number
          period: string
          receipts: number
          remarks: string
          sort_index: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string
          entry_date?: string | null
          id?: string
          payments?: number
          period?: string
          receipts?: number
          remarks?: string
          sort_index?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          entry_date?: string | null
          id?: string
          payments?: number
          period?: string
          receipts?: number
          remarks?: string
          sort_index?: number
          updated_at?: string
        }
        Relationships: []
      }
      demand_items: {
        Row: {
          created_at: string
          demand_id: string
          description: string
          id: string
          qty: number
          rate: number
          ref: string
          remarks: string
          sort_index: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          demand_id: string
          description?: string
          id?: string
          qty?: number
          rate?: number
          ref?: string
          remarks?: string
          sort_index?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          demand_id?: string
          description?: string
          id?: string
          qty?: number
          rate?: number
          ref?: string
          remarks?: string
          sort_index?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "demand_items_demand_id_fkey"
            columns: ["demand_id"]
            isOneToOne: false
            referencedRelation: "demands"
            referencedColumns: ["id"]
          },
        ]
      }
      demands: {
        Row: {
          created_at: string
          demand_date: string | null
          demand_no: string
          id: string
          project: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          demand_date?: string | null
          demand_no?: string
          id?: string
          project?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          demand_date?: string | null
          demand_no?: string
          id?: string
          project?: string
          updated_at?: string
        }
        Relationships: []
      }
      employees: {
        Row: {
          camp_site: string
          cnic_no: string
          created_at: string
          current_salary: number
          department: string
          designation: string
          district: string
          employee_name: string
          experience: string
          father_name: string
          id: string
          job_description: string
          joining_date: string | null
          kin_contact_no: string
          mobile_no: string
          qualification: string
          reference_by: string
          relation: string
          revised_date: string | null
          revised_salary: number | null
          tehsil: string
          updated_at: string
          village: string
        }
        Insert: {
          camp_site?: string
          cnic_no?: string
          created_at?: string
          current_salary?: number
          department?: string
          designation?: string
          district?: string
          employee_name?: string
          experience?: string
          father_name?: string
          id?: string
          job_description?: string
          joining_date?: string | null
          kin_contact_no?: string
          mobile_no?: string
          qualification?: string
          reference_by?: string
          relation?: string
          revised_date?: string | null
          revised_salary?: number | null
          tehsil?: string
          updated_at?: string
          village?: string
        }
        Update: {
          camp_site?: string
          cnic_no?: string
          created_at?: string
          current_salary?: number
          department?: string
          designation?: string
          district?: string
          employee_name?: string
          experience?: string
          father_name?: string
          id?: string
          job_description?: string
          joining_date?: string | null
          kin_contact_no?: string
          mobile_no?: string
          qualification?: string
          reference_by?: string
          relation?: string
          revised_date?: string | null
          revised_salary?: number | null
          tehsil?: string
          updated_at?: string
          village?: string
        }
        Relationships: []
      }
      salary_entries: {
        Row: {
          advance: number
          created_at: string
          days: number
          department: string
          designation: string
          employee_id: string | null
          employee_name: string
          gross_salary: number
          id: string
          joining_date: string | null
          period: string
          sort_index: number
          updated_at: string
        }
        Insert: {
          advance?: number
          created_at?: string
          days?: number
          department?: string
          designation?: string
          employee_id?: string | null
          employee_name?: string
          gross_salary?: number
          id?: string
          joining_date?: string | null
          period?: string
          sort_index?: number
          updated_at?: string
        }
        Update: {
          advance?: number
          created_at?: string
          days?: number
          department?: string
          designation?: string
          employee_id?: string | null
          employee_name?: string
          gross_salary?: number
          id?: string
          joining_date?: string | null
          period?: string
          sort_index?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "salary_entries_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
