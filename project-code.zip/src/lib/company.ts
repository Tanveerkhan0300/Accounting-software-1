import { useSetting } from "@/lib/db";

export type Company = {
  short: string;
  name: string;
  project: string;
};

export const COMPANY_FALLBACK: Company = {
  short: "ALM",
  name: "Al Mehreen Enterprises ( ALM ) Roads",
  project: "Chitral Project (ALM) Birmough To Istor",
};

/** Editable company / project heading used on every sheet, print and export. */
export function useCompany() {
  const store = useSetting<Company>("company_profile", COMPANY_FALLBACK);
  return { company: store.value, save: store.save, isLoading: store.isLoading };
}
