/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";

const client = supabase as any;

export type Row = Record<string, any>;

/** Read every row of a table (RLS keeps it to signed-in staff). */
export function useRows<T extends Row = Row>(
  table: string,
  opts?: { orderBy?: string; ascending?: boolean; filter?: Record<string, unknown> },
) {
  const orderBy = opts?.orderBy ?? "sort_index";
  return useQuery({
    queryKey: [table, opts?.filter ?? null],
    queryFn: async (): Promise<T[]> => {
      let q = client.from(table).select("*");
      if (opts?.filter) {
        for (const [k, v] of Object.entries(opts.filter)) q = q.eq(k, v);
      }
      const { data, error } = await q
        .order(orderBy, { ascending: opts?.ascending ?? true })
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as T[];
    },
    staleTime: 60_000,
    gcTime: 10 * 60_000,
    refetchOnWindowFocus: false,
    placeholderData: (prev: T[] | undefined) => prev,
  });
}

export function useRowMutations(table: string) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: [table] });

  const insert = useMutation({
    mutationFn: async (values: Row) => {
      const { data, error } = await client.from(table).insert(values).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: invalidate,
    onError: (e: any) => toast.error(e.message ?? "Could not save"),
  });

  /** Optimistic in-place update: UI reacts instantly, no refetch round-trip. */
  const update = useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Row }) => {
      const { error } = await client.from(table).update(values).eq("id", id);
      if (error) throw error;
    },
    onMutate: ({ id, values }: { id: string; values: Row }) => {
      qc.getQueriesData({ queryKey: [table] }).forEach(([key, data]) => {
        if (!Array.isArray(data)) return;
        qc.setQueryData(
          key,
          (data as Row[]).map((r) => (r["id"] === id ? { ...r, ...values } : r)),
        );
      });
    },
    onError: (e: any) => {
      toast.error(e.message ?? "Could not update");
      invalidate();
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await client.from(table).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Deleted");
    },
    onError: (e: any) => toast.error(e.message ?? "Could not delete"),
  });

  return { insert, update, remove };
}

/** Key/value settings row (used for cash book opening balance, headings, etc.). */
export function useSetting<T extends Row>(key: string, fallback: T) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["app_settings", key],
    queryFn: async (): Promise<T> => {
      const { data, error } = await client
        .from("app_settings")
        .select("value")
        .eq("key", key)
        .maybeSingle();
      if (error) throw error;
      return { ...fallback, ...((data?.value ?? {}) as T) };
    },
  });

  const save = useMutation({
    mutationFn: async (value: T) => {
      const { error } = await client
        .from("app_settings")
        .upsert({ key, value }, { onConflict: "key" });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["app_settings", key] }),
    onError: (e: any) => toast.error(e.message ?? "Could not save settings"),
  });

  return { value: query.data ?? fallback, isLoading: query.isLoading, save };
}
