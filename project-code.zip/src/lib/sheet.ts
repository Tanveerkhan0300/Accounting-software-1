import * as XLSX from "xlsx";

export type Cell = string | number | null;

/** Format a number the Excel way used across ALM sheets: 1,234 and "-" for zero. */
export function fmt(n: number | null | undefined): string {
  const v = Number(n ?? 0);
  if (!v) return "-";
  return v.toLocaleString("en-US", { maximumFractionDigits: 0 });
}

export function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export function fmtDate(d: string | null | undefined): string {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return String(d);
  return `${dt.getDate()}/${dt.getMonth() + 1}/${dt.getFullYear()}`;
}

/** Export a plain array-of-arrays as a real .xlsx workbook. */
export function exportSheet(
  filename: string,
  rows: Cell[][],
  opts?: { sheetName?: string; colWidths?: number[]; merges?: XLSX.Range[] },
) {
  const ws = XLSX.utils.aoa_to_sheet(rows);
  if (opts?.colWidths) ws["!cols"] = opts.colWidths.map((w) => ({ wch: w }));
  if (opts?.merges) ws["!merges"] = opts.merges;
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opts?.sheetName ?? "Sheet1");
  XLSX.writeFile(wb, filename.endsWith(".xlsx") ? filename : `${filename}.xlsx`);
}

/** Export a CSV (opens directly in Excel) — handy for quick downloads. */
export function exportCsv(filename: string, rows: Cell[][]) {
  const csv = rows
    .map((r) =>
      r
        .map((c) => {
          const s = c == null ? "" : String(c);
          return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        })
        .join(","),
    )
    .join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/** Print only one printable block of the page. */
export function printBlock(id: string, title = "ALM") {
  const el = document.getElementById(id);
  if (!el) return;
  const w = window.open("", "_blank", "width=1100,height=800");
  if (!w) return;
  w.document.write(`<!doctype html><html><head><title>${title}</title>
  <style>
    *{box-sizing:border-box}
    body{font-family:"Segoe UI",Arial,sans-serif;font-size:11px;margin:16px;color:#000}
    table{border-collapse:collapse;width:100%}
    th,td{border:1px solid #000;padding:4px 6px;vertical-align:middle}
    th{background:#e8e8e8;font-weight:700;text-align:center}
    .t-center{text-align:center}.t-right{text-align:right}.bold{font-weight:700}
    .doc-title{text-align:center;font-weight:700;font-size:14px}
    input,textarea,select{border:0;background:transparent;font:inherit;color:#000;width:100%;padding:0;text-align:inherit;appearance:none}
    .no-print{display:none!important}
    @page{size:A4 landscape;margin:10mm}
  </style></head><body>${el.innerHTML}</body></html>`);
  w.document.querySelectorAll<HTMLInputElement>("input").forEach(() => {});
  // carry current input values into the printed markup
  const srcInputs = el.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("input,textarea");
  const dstInputs = w.document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
    "input,textarea",
  );
  srcInputs.forEach((s, i) => {
    const d = dstInputs[i];
    if (d) d.setAttribute("value", s.value);
    if (d && d.tagName === "TEXTAREA") d.textContent = s.value;
  });
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}

const ones = [
  "",
  "One",
  "Two",
  "Three",
  "Four",
  "Five",
  "Six",
  "Seven",
  "Eight",
  "Nine",
  "Ten",
  "Eleven",
  "Twelve",
  "Thirteen",
  "Fourteen",
  "Fifteen",
  "Sixteen",
  "Seventeen",
  "Eighteen",
  "Nineteen",
];
const tens = [
  "",
  "",
  "Twenty",
  "Thirty",
  "Forty",
  "Fifty",
  "Sixty",
  "Seventy",
  "Eighty",
  "Ninety",
];

function below1000(n: number): string {
  if (n < 20) return ones[n] ?? "";
  if (n < 100)
    return `${tens[Math.floor(n / 10)] ?? ""}${n % 10 ? ` ${ones[n % 10] ?? ""}` : ""}`;
  return `${ones[Math.floor(n / 100)] ?? ""} Hundred${n % 100 ? ` ${below1000(n % 100)}` : ""}`;
}

/** Rupees in words (Pakistani numbering: crore / lakh / thousand). */
export function rupeesInWords(amount: number): string {
  let n = Math.floor(Math.abs(num(amount)));
  if (!n) return "Rupees Zero Only";
  const parts: string[] = [];
  const crore = Math.floor(n / 10000000);
  n %= 10000000;
  const lakh = Math.floor(n / 100000);
  n %= 100000;
  const thousand = Math.floor(n / 1000);
  n %= 1000;
  if (crore) parts.push(`${below1000(crore)} Crore`);
  if (lakh) parts.push(`${below1000(lakh)} Lakh`);
  if (thousand) parts.push(`${below1000(thousand)} Thousand`);
  if (n) parts.push(below1000(n));
  return `Rupees ${parts.join(" ")} Only`;
}

export const MONTHS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

export function periodLabel(period: string): string {
  const [y, m] = period.split("-");
  const mi = Number(m) - 1;
  if (!y || mi < 0 || mi > 11) return period;
  return `${MONTHS[mi] ?? ""}-${y.slice(2)}`;
}

export function currentPeriod(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
