import { useEffect, useRef, useState, type ReactNode } from "react";
import { Download, Printer, Plus, Trash2, FileSpreadsheet, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

export function ToolBar({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="no-print mb-5 overflow-hidden rounded-xl border border-border bg-card shadow-sm">
      <div className="h-1 w-full bg-gradient-to-r from-primary via-ring to-accent" />
      <div className="flex flex-wrap items-end justify-between gap-3 px-4 py-3">
        <div>
          <h1 className="font-display text-xl font-bold tracking-tight text-foreground">{title}</h1>
          {subtitle ? <p className="text-xs text-muted-foreground">{subtitle}</p> : null}
        </div>
        <div className="flex flex-wrap items-center gap-2">{children}</div>
      </div>
    </div>
  );
}

export function ExcelButton({ onClick, label = "Export Excel" }: { onClick: () => void; label?: string }) {
  return (
    <Button variant="secondary" size="sm" onClick={onClick}>
      <FileSpreadsheet className="mr-1.5 size-4" /> {label}
    </Button>
  );
}

export function CsvButton({ onClick }: { onClick: () => void }) {
  return (
    <Button variant="outline" size="sm" onClick={onClick}>
      <Download className="mr-1.5 size-4" /> Download CSV
    </Button>
  );
}

export function PrintButton({ onClick }: { onClick: () => void }) {
  return (
    <Button variant="outline" size="sm" onClick={onClick}>
      <Printer className="mr-1.5 size-4" /> Print
    </Button>
  );
}

export function AddButton({ onClick, label = "Add Row" }: { onClick: () => void; label?: string }) {
  return (
    <Button size="sm" onClick={onClick}>
      <Plus className="mr-1.5 size-4" /> {label}
    </Button>
  );
}

export function DeleteButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title="Delete row"
      className="no-print inline-flex size-7 items-center justify-center rounded-md text-destructive transition-colors hover:bg-destructive/10"
    >
      <Trash2 className="size-4" />
    </button>
  );
}

/** Excel-look wrapper: white paper, hard 1px grid, tight rows. */
export function Paper({ id, children }: { id: string; children: ReactNode }) {
  return (
    <div id={id} className="overflow-x-auto rounded-lg border border-border bg-card p-4 shadow-sm">
      {children}
    </div>
  );
}

/** Small coloured KPI chip used above sheets. */
export function StatChip({
  label,
  value,
  tone = "primary",
}: {
  label: string;
  value: string;
  tone?: "primary" | "positive" | "negative" | "muted";
}) {
  const tones: Record<string, string> = {
    primary: "border-primary/25 bg-primary/10 text-primary",
    positive: "border-emerald-500/25 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
    negative: "border-destructive/25 bg-destructive/10 text-destructive",
    muted: "border-border bg-muted text-muted-foreground",
  };
  return (
    <div className={`rounded-lg border px-3 py-2 ${tones[tone]}`}>
      <div className="text-[11px] font-medium uppercase tracking-wide opacity-80">{label}</div>
      <div className="font-display text-base font-bold tabular-nums">{value}</div>
    </div>
  );
}

export function SheetTitle({ lines }: { lines: string[] }) {
  return (
    <div className="mb-2 space-y-0.5">
      {lines.map((l, i) => (
        <div
          key={i}
          className={`doc-title text-center ${i === 0 ? "text-base font-bold" : "text-sm font-semibold"}`}
        >
          {l}
        </div>
      ))}
    </div>
  );
}

/**
 * Save button — commits whatever cell is being typed in right now
 * (cells save on blur / Enter) and confirms to the user.
 */
export function SaveButton({ label = "Save" }: { label?: string }) {
  return (
    <Button
      size="sm"
      variant="default"
      onClick={() => {
        const el = document.activeElement as HTMLElement | null;
        el?.blur?.();
        setTimeout(() => toast.success("Data saved to database"), 50);
      }}
    >
      <Save className="mr-1.5 size-4" /> {label}
    </Button>
  );
}

/**
 * Borderless input inside an Excel-style cell.
 * Types locally and commits on blur or Enter, so the database is written once
 * per edit instead of on every keystroke.
 */
export function CellInput({
  value,
  onChange,
  type = "text",
  align = "left",
  placeholder,
  className = "",
}: {
  value: string | number;
  onChange: (v: string) => void;
  type?: "text" | "number" | "date";
  align?: "left" | "center" | "right";
  placeholder?: string;
  className?: string;
}) {
  const [draft, setDraft] = useState<string>(String(value ?? ""));
  const focused = useRef(false);

  useEffect(() => {
    if (!focused.current) setDraft(String(value ?? ""));
  }, [value]);

  const commit = () => {
    if (draft !== String(value ?? "")) onChange(draft);
  };

  // Numbers render as plain text fields (inputMode numeric) so there are no
  // up/down spinner arrows — the user just types the amount.
  const inputType = type === "number" ? "text" : type;

  return (
    <input
      type={inputType}
      inputMode={type === "number" ? "decimal" : undefined}
      value={draft}
      placeholder={placeholder}
      onFocus={() => {
        focused.current = true;
      }}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        focused.current = false;
        commit();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.currentTarget as HTMLInputElement).blur();
      }}
      className={`w-full min-w-0 bg-transparent px-1 py-0.5 outline-none focus:bg-accent/60 ${className}`}
      style={{ textAlign: align }}
    />
  );
}
