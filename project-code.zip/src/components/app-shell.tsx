import { Link, useRouter } from "@tanstack/react-router";
import {
  BookOpenCheck,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  ReceiptText,
  Users,
  Wallet,
  Coins,
  Settings,
} from "lucide-react";
import { type ReactNode } from "react";

import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company";
import { Button } from "@/components/ui/button";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/cash-book", label: "Cash Book", icon: BookOpenCheck },
  { to: "/salary", label: "Staff Salary Sheet", icon: Wallet },
  { to: "/payslip", label: "Salary Payslip", icon: ReceiptText },
  { to: "/employees", label: "Employee Profiles", icon: Users },
  { to: "/demand", label: "Demand Sheet", icon: ClipboardList },
  { to: "/advance", label: "Advance Salaries", icon: Coins },
  { to: "/settings", label: "Company Settings", icon: Settings },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const { company } = useCompany();

  const signOut = async () => {
    await supabase.auth.signOut();
    router.navigate({ to: "/auth" });
  };

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="no-print sticky top-0 hidden h-screen w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="border-b border-sidebar-border px-5 py-4">
          <div className="font-display text-lg font-extrabold tracking-tight text-sidebar-primary">
            {company.short}
          </div>
          <div className="text-xs leading-tight text-sidebar-foreground/70">
            {company.name}
            <br />
            {company.project}
          </div>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className="flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium text-sidebar-foreground/85 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              activeProps={{
                className:
                  "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-semibold bg-sidebar-accent text-sidebar-primary",
              }}
            >
              <Icon className="size-4" />
              {label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={signOut}
            className="w-full justify-start text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          >
            <LogOut className="mr-2 size-4" /> Sign out
          </Button>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="no-print flex items-center gap-3 overflow-x-auto border-b border-border bg-card px-4 py-2 md:hidden">
          {NAV.map(({ to, label }) => (
            <Link key={to} to={to} className="whitespace-nowrap text-xs font-medium">
              {label}
            </Link>
          ))}
        </header>
        <main className="p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
